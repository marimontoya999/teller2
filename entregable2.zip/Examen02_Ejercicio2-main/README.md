Danilo Andres Lozano Tamayo -
Juan Esteban Hernandez Cristiano

